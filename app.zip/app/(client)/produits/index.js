import {View , Text} from "react-native";

export default function ProduitsClients() {
    return (
        <View>
            <Text>Page Produits</Text>
        </View>
    )
}