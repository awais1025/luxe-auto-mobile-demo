import { View, Text} from "react-native";

export default function AdminIndex() {
    return (
        <View >
            <Text>Bienvenue sur la page d'administration</Text>
        </View>
    );
}
