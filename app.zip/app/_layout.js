import { Stack } from "expo-router";
import { SQLiteProvider } from "expo-sqlite";
import { useEffect, useState } from "react";
import * as SQLite from "expo-sqlite";

async function initDB(db) {
  const result = await db.getFirstAsync("PRAGMA user_version");
  const currentVersion = result?.user_version || 0;
  if (currentVersion < 1) {
    await db.execAsync(`
        CREATE TABLE IF NOT EXISTS Produit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT,
        description TEXT,
        prix INTEGER,
        image TEXT
      );

      CREATE TABLE IF NOT EXISTS Client (
        nom TEXT PRIMARY KEY,
        mdp TEXT,
        admin INTEGER, 
        adresse TEXT,
        langue TEXT
      );

      INSERT OR IGNORE INTO Client (nom, mdp, admin, adresse, langue)
      VALUES ('admin', 'password', 1, '1234', 'fr');
    `);
    await db.execAsync("PRAGMA user_version = 1;");
  }
}

export default function RootLayout() {
  return (
    <SQLiteProvider databaseName="pfi.db" onInit={initDB}>
      <Stack>
        <Stack.Screen name="index" options={{ headerShown: false }}/>
        <Stack.Screen name="(client)" options={{ headerShown: false }} />
        <Stack.Screen name="(admin)" options={{ headerShown: false }} />
      </Stack>
    </SQLiteProvider>
  );
}